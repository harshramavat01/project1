import React, { Component } from 'react'

export default class Gt extends Component {
  render() {
    return (
      <div>Gt</div>
    )
  }
}
